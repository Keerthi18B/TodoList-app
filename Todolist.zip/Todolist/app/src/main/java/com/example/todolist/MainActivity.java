package com.example.todolist;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.FileOutputStream;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private EditText taskName, taskDescription, taskDate, taskTime;
    private Button selectDateButton, selectTimeButton;
    private static final int NOTIFICATION_PERMISSION_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskName = findViewById(R.id.taskName);
        taskDescription = findViewById(R.id.taskDescription);
        taskDate = findViewById(R.id.taskDate);
        taskTime = findViewById(R.id.taskTime);
        selectDateButton = findViewById(R.id.selectDateButton);
        selectTimeButton = findViewById(R.id.selectTimeButton);

        requestNotificationPermission();
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_CODE
                );
            }
        }
    }

    public void showDatePickerDialog(View view) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view1, selectedYear, selectedMonth, selectedDay) -> {
                    String date = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                    taskDate.setText(date);
                }, year, month, day);
        datePickerDialog.show();
    }

    public void showTimePickerDialog(View view) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (view1, selectedHour, selectedMinute) -> {
                    String time = String.format("%02d:%02d", selectedHour, selectedMinute);
                    taskTime.setText(time);
                }, hour, minute, true);
        timePickerDialog.show();
    }

    public void addTask(View view) {
        String name = taskName.getText().toString();
        String description = taskDescription.getText().toString();
        String date = taskDate.getText().toString();
        String time = taskTime.getText().toString();

        if (name.isEmpty() || date.isEmpty() || time.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String task = name + ";" + description + ";" + date + ";" + time + ";incomplete\n";

        try {
            FileOutputStream fos = openFileOutput("tasks.txt", MODE_APPEND);
            fos.write(task.getBytes());
            fos.close();
            Toast.makeText(this, "Task Added", Toast.LENGTH_SHORT).show();

            // Clear inputs after successful save
            taskName.setText("");
            taskDescription.setText("");
            taskDate.setText("");
            taskTime.setText("");

            scheduleNotification(name, date, time);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Error saving task", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("ScheduleExactAlarm")
    private void scheduleNotification(String taskName, String date, String time) {
        try {
            String[] dateParts = date.split("/");
            String[] timeParts = time.split(":");

            int day = Integer.parseInt(dateParts[0]);
            int month = Integer.parseInt(dateParts[1]) - 1;
            int year = Integer.parseInt(dateParts[2]);
            int hour = Integer.parseInt(timeParts[0]);
            int minute = Integer.parseInt(timeParts[1]);

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, day);
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.set(Calendar.SECOND, 0);

            // Subtract 5 minutes from the scheduled time
            calendar.add(Calendar.MINUTE, -5);

            Intent intent = new Intent(this, NotificationReceiver.class);
            intent.putExtra("taskName", taskName);

            // Generate unique request code based on task details
            int requestCode = (taskName + date + time).hashCode();

            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    this,
                    requestCode,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis(),
                        pendingIntent
                );
            } else {
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        calendar.getTimeInMillis(),
                        pendingIntent
                );
            }


            // Debug logging
            long currentTime = System.currentTimeMillis();
            long scheduledTime = calendar.getTimeInMillis();
            Log.d("NotificationDebug", "Current time: " + currentTime);
            Log.d("NotificationDebug", "Scheduled time: " + scheduledTime);
            Log.d("NotificationDebug", "Time until notification: " +
                    (scheduledTime - currentTime) / 1000 + " seconds");

            Toast.makeText(this, "Notification Scheduled 5 minutes before task", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("NotificationDebug", "Error scheduling notification", e);
            Toast.makeText(this, "Error scheduling notification", Toast.LENGTH_SHORT).show();
        }
    }

    public void viewTasks(View view) {
        Intent intent = new Intent(this, ViewTasksActivity.class);
        startActivity(intent);
    }
}