package com.example.todolist;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ViewTasksActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayList<String> tasks;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_tasks);

        listView = findViewById(R.id.listView);
        tasks = new ArrayList<>();

        loadTasks();

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                markTaskAsCompleted(position);
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                deleteTask(position);
                return true;
            }
        });
    }

    private void loadTasks() {
        try {
            FileInputStream fis = openFileInput("tasks.txt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String line;

            while ((line = reader.readLine()) != null) {
                tasks.add(line);
            }

            reader.close();
            fis.close();

            adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tasks);
            listView.setAdapter(adapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void markTaskAsCompleted(int position) {
        String task = tasks.get(position);
        if (task.contains("incomplete")) {
            task = task.replace("incomplete", "completed");
            tasks.set(position, task);
            saveTasks();
            Toast.makeText(this, "Task marked as completed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Task is already completed", Toast.LENGTH_SHORT).show();
        }
        adapter.notifyDataSetChanged();
    }

    private void deleteTask(int position) {
        tasks.remove(position);
        saveTasks();
        adapter.notifyDataSetChanged();
        Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show();
    }

    private void saveTasks() {
        try {
            FileOutputStream fos = openFileOutput("tasks.txt", MODE_PRIVATE);
            for (String task : tasks) {
                fos.write((task + "\n").getBytes());
            }
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void goBack(View view) {
        finish();
    }
}
